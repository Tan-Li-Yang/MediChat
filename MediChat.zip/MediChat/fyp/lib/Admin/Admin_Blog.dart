import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fyp/Admin/Admin_Home.dart';
import 'package:fyp/components/rounded_button.dart';
import 'package:fyp/components/rounded_input.dart';
import 'package:intl/intl.dart';

class AdminBlog extends StatefulWidget {
  const AdminBlog({Key? key}) : super(key: key);

  @override
  _AdminBlogState createState() => _AdminBlogState();
}

class _AdminBlogState extends State<AdminBlog> {
  final TextEditingController date = TextEditingController();
  final TextEditingController title = TextEditingController();
  final TextEditingController description = TextEditingController();
  final TextEditingController link = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (pickedDate != null) {
      setState(() {
        date.text = DateFormat('yyyy-MM-dd').format(pickedDate);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 211, 241, 223),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 211, 241, 223),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.chevron_left),
          iconSize: 40,
        ),
        title: Text(
          "Add Meal Record",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 30,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Form(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () => _selectDate(context),
                      child: AbsorbPointer(
                        child: RoundedInput(
                          controller: date,
                          icon: Icons.date_range,
                          hint: "Date (yyyy-MM-dd):",
                        ),
                      ),
                    ),
                    RoundedInput(
                      controller: title,
                      icon: Icons.date_range,
                      hint: "Enter Title:",
                    ),
                    RoundedInput(
                      controller: description,
                      icon: Icons.description,
                      hint: "Enter Description of blog:",
                    ),
                    RoundedInput(
                      controller: link,
                      icon: Icons.link_off_outlined,
                      hint: "Enter link:",
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      width: double.infinity,
                      child: RoundedButton(
                          title: "Add",
                          onPressed: () {
                            if (date.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("Date cannot be empty!")),
                              );
                              return;
                            }

                            if (title.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("title cannot be empty!")),
                              );
                              return;
                            }

                            if (description.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("Description cannot be empty!")),
                              );
                              return;
                            }

                            if (link.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("link cannot be empty!")),
                              );
                              return;
                            }

                            _AddBlog(); // Proceed if all inputs are valid
                          }
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _AddBlog() async {
    MethodChannel platform = MethodChannel('AdBlog');
    try {
      final String result = await platform.invokeMethod('UploadBlog', {
        "date": date.text,
        "title": title.text,
        "description": description.text,
        "link": link.text
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Blog Added Successfully"),
          duration: Duration(seconds: 1), // Set the duration to 1 second
        ),
      );

      await Future.delayed(Duration(seconds: 1));
      Navigator.pop(context);  // To pop the current screen before pushing the new screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => AdminHome()),
      );
    } on PlatformException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("${e.message}")));
    }
  }
}
