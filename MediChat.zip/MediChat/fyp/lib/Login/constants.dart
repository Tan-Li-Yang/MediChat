import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF66BB6A);
const kBackgroundColor = Color(0xFFE8F5E9);